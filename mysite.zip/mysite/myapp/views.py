# myapp/views.py

from django.shortcuts import render
from .services import get_option_data, detect_unusual_activity, analyze_yahoo_sentiment

def unusual_activity_view(request, stock_symbol):
    option_data = get_option_data(stock_symbol)
    unusual_options = detect_unusual_activity(option_data, volume_threshold=10000, otm_threshold=0.2)
    
    # Sentiment Analysis
    sentiment = analyze_yahoo_sentiment(stock_symbol)
    
    context = {
        'stock_symbol': stock_symbol,
        'unusual_options': unusual_options,
        'sentiment': sentiment,
    }
    return render(request, 'unusual_activity.html', context)
