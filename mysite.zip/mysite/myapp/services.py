import yfinance as yf
import matplotlib.pyplot as plt
import numpy as np
from scipy.stats import norm
from datetime import datetime
import pandas as pd
import requests
import json
from json import JSONDecodeError
from selenium import webdriver
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time
from pyfin.sentiment import SentimentAnalyzer  # Importing the sentiment analyzer

# Declare global variable for sentiment model
_sentiment_model = None

# Initialize the sentiment analyzer
def load_sentiment_model():
    # Initialize the sentiment analyzer from pyfin-sentiment
    return SentimentAnalyzer()

# Function to analyze sentiment using the loaded model
def analyze_sentiment(comments):
    model = load_sentiment_model()
    sentiment_results = []
    
    for comment in comments:
        # Analyze sentiment for each comment
        sentiment = model.predict(comment)
        sentiment_results.append(sentiment)

    return sentiment_results

# Function to calculate days until target date
def getDaysUntil(targetDate):
    if isinstance(targetDate, str):
        target_date = datetime.strptime(targetDate, '%Y-%m-%d')
    elif isinstance(targetDate, datetime):
        target_date = targetDate
    else:
        raise TypeError("targetDate must be a string or datetime object")
    
    today = datetime.now()
    days_until = (target_date - today).days
    return days_until

# Function to fetch option data and calculate Greeks (Delta, Gamma)
def get_option_data(ticker_symbol):
    stock = yf.Ticker(ticker_symbol)
    expiry_list = stock.options
    all_option_data = []

    for expiry in expiry_list:
        option_chain = stock.option_chain(expiry)
        
        calls = option_chain.calls
        puts = option_chain.puts
        
        r = 0.01  # Example risk-free rate
        T = getDaysUntil(expiry) / 365.0  # Time to expiration in years
        S = stock.history(period='1d')['Close'].iloc[-1]  # Current stock price

        def calculate_greeks(S, K, T, r, sigma, option_type='call'):
            if sigma <= 0 or T <= 0:
                return 0, 0

            d1 = (np.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
            d2 = d1 - sigma * np.sqrt(T)
            
            if option_type == 'call':
                delta = norm.cdf(d1)
            elif option_type == 'put':
                delta = norm.cdf(d1) - 1
            gamma = norm.pdf(d1) / (S * sigma * np.sqrt(T))
            
            return delta, gamma
        
        for _, row in calls.iterrows():
            strike = row['strike']
            sigma = row['impliedVolatility'] if row['impliedVolatility'] > 0 else 0.001
            delta, gamma = calculate_greeks(S, strike, T, r, sigma, option_type='call')
            all_option_data.append({
                'expiry': expiry,
                'type': 'call',
                'strike': strike,
                'volume': row['volume'],
                'impliedVolatility': sigma,
                'delta': delta,
                'gamma': gamma
            })
        
        for _, row in puts.iterrows():
            strike = row['strike']
            sigma = row['impliedVolatility'] if row['impliedVolatility'] > 0 else 0.001
            delta, gamma = calculate_greeks(S, strike, T, r, sigma, option_type='put')
            all_option_data.append({
                'expiry': expiry,
                'type': 'put',
                'strike': strike,
                'volume': row['volume'],
                'impliedVolatility': sigma,
                'delta': delta,
                'gamma': gamma
            })

    return pd.DataFrame(all_option_data)

# Function to detect unusual options activity
def detect_unusual_activity(option_data, volume_threshold, otm_threshold):
    unusual_calls = option_data[(option_data['volume'] > volume_threshold) & 
                                (option_data['delta'] < (1 - otm_threshold))]
    return unusual_calls

# Set up Selenium WebDriver
def init_driver():
    options = webdriver.ChromeOptions()
    options.add_argument("--headless")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")
    return webdriver.Chrome(options=options)

def fetch_yahoo_finance_comments(ticker_symbol):
    url = f"https://finance.yahoo.com/quote/{ticker_symbol}/community"
    driver = init_driver()
    driver.get(url)
    time.sleep(5)  # Allow page to load

    # Scroll down to load more comments
    for _ in range(10):  # Increase scroll count
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        time.sleep(5)  # Extended wait time

    # Parse the page source with BeautifulSoup
    soup = BeautifulSoup(driver.page_source, 'html.parser')
    driver.quit()

    # Debugging: print the HTML for inspection
    print(soup.prettify())  

    # Extract comments based on observed HTML structure
    comments = []
    comment_elements = soup.find_all('p', class_='comment')  # Update this class based on current structure
    for element in comment_elements:
        comments.append(element.get_text())

    # Debugging: print the extracted comments
    print(comments)

    return comments

# Analyze sentiment for comments from Yahoo Finance
def analyze_yahoo_sentiment(ticker_symbol):
    comments = fetch_yahoo_finance_comments(ticker_symbol)
    if not comments:
        print(f"No comments found for {ticker_symbol} on Yahoo Finance.")
        return {'positive': 0, 'neutral': 0, 'negative': 0}

    sentiments = analyze_sentiment(comments)

    positive_sentiments = sum(1 for s in sentiments if s['label'] == 'POSITIVE')
    negative_sentiments = sum(1 for s in sentiments if s['label'] == 'NEGATIVE')
    neutral_sentiments = len(comments) - positive_sentiments - negative_sentiments

    return {
        'positive': positive_sentiments,
        'neutral': neutral_sentiments,
        'negative': negative_sentiments
    }

# Fetch financial information
def get_financial_info(ticker_symbol):
    stock = yf.Ticker(ticker_symbol)
    balance_sheet = stock.balance_sheet
    cashflow = stock.cashflow
    analysis = stock.analysis
    return balance_sheet, cashflow, analysis

# Visualize options activity
def visualize_option_activity(option_data):
    plt.figure(figsize=(10,6))
    
    unusual_calls = option_data[(option_data['volume'] > 10000) & (option_data['delta'] < 0.8)]
    
    plt.bar(option_data['strike'], option_data['volume'], color='blue', label='Normal Volume')
    if not unusual_calls.empty:  # Check if unusual calls exist
        plt.bar(unusual_calls['strike'], unusual_calls['volume'], color='red', label='Unusual Volume')
    
    plt.title('Option Volume by Strike Price')
    plt.xlabel('Strike Price')
    plt.ylabel('Volume')
    plt.legend()
    plt.show()
