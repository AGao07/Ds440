# myapp/urls.py

from django.urls import path
from . import views  # Import views from the same app

urlpatterns = [
    path('unusual-activity/<str:stock_symbol>/', views.unusual_activity_view, name='unusual_activity'),
]
